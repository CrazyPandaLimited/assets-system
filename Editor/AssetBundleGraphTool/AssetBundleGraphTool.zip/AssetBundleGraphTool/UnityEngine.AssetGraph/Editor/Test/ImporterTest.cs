﻿#if UNITY_5_6_OR_NEWER
using UnityEngine;
using UnityEditor;
//using UnityEngine.TestTools;
using NUnit.Framework;
using System.Collections;
using System.IO;
using UnityEngine.AssetGraph;

using UnityEngine.AssetGraph.DataModel.Version2;

public class ImporterTest {

//	[Test]
//	public void ModelImporterIsEqualToSelf() {
//        AssetImporter imp = AssetImporter.GetAtPath (Settings.Path.SettingTemplateModel);
//
//        ImportSettingsConfigurator c = new ImportSettingsConfigurator (imp);
//        ConfigurationOption o = new ConfigurationOption ();
//
//        Assert.IsTrue( c.IsEqual (imp, o) );
//    }
//
//    [Test]
//    public void AudioImporterIsEqualToSelf() {
//        AssetImporter imp = AssetImporter.GetAtPath (Settings.Path.SettingTemplateAudio);
//
//        ImportSettingsConfigurator c = new ImportSettingsConfigurator (imp);
//        ConfigurationOption o = new ConfigurationOption ();
//
//        Assert.IsTrue( c.IsEqual (imp, o) );
//    }
//
//    [Test]
//    public void VideoImporterIsEqualToSelf() {
//        AssetImporter imp = AssetImporter.GetAtPath (Settings.Path.SettingTemplateVideo);
//
//        ImportSettingsConfigurator c = new ImportSettingsConfigurator (imp);
//        ConfigurationOption o = new ConfigurationOption ();
//
//        Assert.IsTrue( c.IsEqual (imp, o) );
//    }
//
//    [Test]
//    public void TextureImporterIsEqualToSelf() {
//        AssetImporter imp = AssetImporter.GetAtPath (Settings.Path.SettingTemplateTexture);
//
//        ImportSettingsConfigurator c = new ImportSettingsConfigurator (imp);
//        ConfigurationOption o = new ConfigurationOption ();
//
//        Assert.IsTrue( c.IsEqual (imp, o) );
//    }
}
#endif
