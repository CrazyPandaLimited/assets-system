﻿What are these files?

setting.* work with ImportSetting node and used to save asset's import settings.
It is only intended to be copied and hold import settings of each ImportSettings node, and not used anywhere else.
